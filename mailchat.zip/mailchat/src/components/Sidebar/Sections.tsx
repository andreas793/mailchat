import styled from "styled-components";

export const Sections = () => (
    <Wrapper>
        <SectionItem>
            Новые
        </SectionItem>
        <SectionItem>
            Ветки
        </SectionItem>
    </Wrapper>
)

const Wrapper = styled.div``;

const SectionItem = styled.div``;