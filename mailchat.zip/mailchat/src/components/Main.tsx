import styled from "styled-components";

export const Main = () => (
    <Wrapper>
        <h2>Окно диалога</h2>
    </Wrapper>
)

const Wrapper = styled.div`
    display: flex;
    align-items: center;
    justify-content: center;`;